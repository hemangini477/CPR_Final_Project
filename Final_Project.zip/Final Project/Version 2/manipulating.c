/*
Origin:
	Name: Karmkumar Jigneshbhai Patel,
	email: kjpatel40@myseneca.ca,
	ID: 124767211,
	Date written: 01-12-2021,
	Course: CPR 101, Project: Version 2
executable filename: Manipulations
Purpose: Comparing strings
*/


// MANIPULATING V2
#define _CRT_SECURE_NO_WARNINGS

#include "manipulating.h"

// definition of function manipulating
// Comparing Strings
void manipulating()
{	
	/*Version 1*/
	
	printf("*** Start of Concatenating Strings Demo ***\n");

	char string1[80];
	char string2[80];

	printf("Type the 1st string (q - to quit): \n");
	gets(string1);

	// define loop to concate strings until quit
	while (strcmp(string1, "q") != 0) // compare string1 with q
	{
		printf("Type the 2nd string: \n");
		gets(string2);
		strcat(string1, string2); // concate string1 and string2 and store it into string1
		printf("Concatenated string is \'%s\'\n", string1);
		printf("Type the 1st string (q - to quit): \n");
		gets(string1);
	}
	printf("*** End of Concatenating Strings Demo ***\n\n");

	/*Version 2*/
	
	printf("*** Start of Comparing Strings Demo ***\n");

	char compare1[80];
	char compare2[80];

	int result;
	printf("Type the 1st string to compare (q - to quit): \n");
	gets(compare1);

	// define loop to compare strings until quit
	while (strcmp(compare1, "q") != 0)
	{
		printf("Type the 2nd string to compare: \n");
		gets(compare2);
		result = strcmp(compare1, compare2); // compare compare1 and compare2 charecter by character

		if (result < 0)
			printf("1st string is less than 2nd\n");
		else if (result == 0)
			printf("1st string is equal to 2nd\n");
		else
			printf("1st string is greater than 2nd\n");
		printf("Type the 1st string to compare (q - to quit): \n");
		gets(compare1);
	}
	printf("*** End of Comparing Strings Demo ***\n\n");
}