#ifndef _FUNDAMENTALS_H
#define _FUNDAMENTALS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void fundamentals();

#endif


