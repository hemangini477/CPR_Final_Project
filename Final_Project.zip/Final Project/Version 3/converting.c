/*
Origin:
	Name: Hemanginiben Nileshbhai Patel,
	email: hnpatel32@myseneca.ca,
	ID: 133892216,
	Date written: 01-12-2021,
	Course: CPR 101, Project: Version 3
executable filename: Conversions
Purpose: Convert long strings to long
*/



// CONVERTING V3
#include "converting.h"

// definition of function coverting()
// converting long strings to long
void converting()
{
	printf("*** Start of Converting Strings to long Demo ***\n");

	char long_string[80];
	long long_number;

	printf("Type the long numeric string (q - to quit): \n");
	gets(long_string);

	// define loop to convert input strings to long until quit
	while (strcmp(long_string, "q") != 0) // compare input string with q
	{
		long_number = atol(long_string); // convert string to double
		printf("Converted number is %ld\n", long_number);
		printf("Type the long numeric string (q - to quit): \n");
		gets(long_string);
	}

	printf("*** End of Converting Strings to long Demo ***\n\n");
}