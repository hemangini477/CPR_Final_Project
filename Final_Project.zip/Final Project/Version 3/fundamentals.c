/*
Origin:
	Name: Harleen Kaur,
	email: hkaur567@myseneca.ca,
	ID: 117416214,
	Date written: 04-12-2021,
	Course: CPR 101, Project: Version 2
executable filename: Fundamentals
Purpose: finding length of string and comparing & copying one string to another   */


 //FUNDAMENTALS V3
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fundamentals.h"

void fundamentals() {
	/* Version 1 */
	printf("***Start of Indexing Strings Demo ***\n");
	char buffer1[80];  //declare char of varable buffer1 with 79 chars plus 1 char for terminator
	char num_input[10]; //declare char of varable num_input  9 chars plus 1 char for terminator
	unsigned int position;  //declare a non-negative int of variable position
	printf("Type not empty string (q - to quit):\n"); //asking the user to enter string or q to quit
	printf("01234567890123456789012345678901234567890123456789012345678901234567890123456789\n");  //prints to screen
	gets(buffer1); //prompt user to enter a string value
	while (strcmp(buffer1, "q") != 0) { //compare ASCII value of first charcater of buffer1 with q 
		printf("Type the character position within the string:\n");  //asking the user to enter the positon of character in string
		gets(num_input); //prompt user to enter a  string value in terms of number 
		position = atoi(num_input); //convert char to int 
		if (position >= strlen(buffer1)) { //compare length of buffer 1 with position
			position = strlen(buffer1) - 1; //assign last character of buffer1 to position  
			printf("Too big... Position reduced to max. available\n");  //prints to screen
		}
		printf("The character found at %d position is \'%c\'\n", position, buffer1[position]);  //prints to screen value of position and buffer1[position]
		printf("Type not empty string (q - to quit):\n"); //asking the user to enter string or q to quitprints to screen
		printf("01234567890123456789012345678901234567890123456789012345678901234567890123456789\n");  //prints to screen
		gets(buffer1); //prompt user to enter a string value and call gets(buffer1) function
	}
	printf("*** End of Indexing Strings Demo ***\n\n"); //prints to screen if q is entered 


/* Version 2 */
 printf(" *** Start of Measuring Strings Demo ***\n");//prints to screen
 char buffer2[80];//declare char of varable buffer2 with 79 chars plus 1 char for terminator
 printf("Type a string (q - to quit):\n");//asking user to enter string or q to quit
 gets(buffer2);//prompt user to enter string
 while (strcmp(buffer2, "q") != 0) { //comparing entered string with 'q'
	printf("The length is %lu\n", strlen(buffer2));//prints length of string 
	printf("Type a string (q - to quit):\n");//asking user to enter string or q to quit
	gets(buffer2);//prompt user to enter string
}
 printf("*** End of Measuring Strings Demo ***\n\n");//prints to screen

 /* Version 3 */
 printf("*** Start of Copying Strings Demo ***\n");//prints to screen
 char destination[80];//declare char of varable destination with 79 chars plus 1 char for terminator
 char source[80];//declare char of varable source with 79 chars plus 1 char for terminator
 destination[0] = '\0';
 printf("Destination string is reset to empty\n");//prints to screen
 printf("Type a source string (q - to quit):\n");//asking user to enter string or q to quit
 gets(source);//prompt user to enter string
 while (strcmp(source, "q") != 0) {//comparing entered string with 'q'
	 strcpy(destination, source); //copy string source to string destination
	 printf("New destination string is \'%s\':\n", destination);//prints new destination string 
	 destination[0] = '\0'; //destination string set to safe state
	 printf("Destination string is reset to empty\n");//prints to screen
	 printf("Type a source string (q - to quit):\n");//asking user to enter string or q to quit
	 gets(source);//prompt user to enter string
 }
 printf("*** End of Copying String Demo ***\n\n");//prints to screen

}


