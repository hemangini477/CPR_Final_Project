/*
Origin:
	Name: Karmkumar Jigneshbhai Patel,
	email: kjpatel40@myseneca.ca,
	ID: 124767211,
	Date written: 01-12-2021,
	Course: CPR 101, Project: Version 3
executable filename: Manipulations
Purpose: Searching strings
*/

// MANIPULATING V3
#define _CRT_SECURE_NO_WARNINGS

#include "manipulating.h"

// definition of function manipulating
// Searching Strings
void manipulating()
{
	printf("*** Start of Searching Strings Demo ***\n");

	char big_string[80];
	char sub_string[80];

	char *address;
	printf("Type the big string (q - to quit): \n");
	gets(big_string);

	// define loop to compare strings until quit
	while (strcmp(big_string, "q") != 0) // compare string1 with q
	{
		printf("Type the substring: \n");
		gets(sub_string);
		address = strstr(big_string, sub_string); // search the postion of sub_string in big_string

		if (address != NULL)
			printf("Found at %ld position\n", (long)address - (long)big_string);
		else
			printf("Not Found\n");
		printf("Type the big string (q - to quit): \n");
		gets(big_string);
	}
	printf("*** End of Searching Strings Demo ***\n\n");
}