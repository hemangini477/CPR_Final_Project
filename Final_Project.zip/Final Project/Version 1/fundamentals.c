/*
Origin:
	Name: Harleen kaur,
	Email: hkaur567@myseneca.ca,
	ID: 117416214,
	Date written: 01-12-2021,
	Course: CPR 101, Project: Version 1
executable filename: Fundamentals
Purpose: finding length of string and comparing one string with another
*/


// FUNDAMENTALS V1
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fundamentals.h"

void fundamentals() {
	/* Version 1 */
	printf("***Start of Indexing Strings Demo ***\n");
	char buffer1[80];  //declare char of varable buffer1 with 79 chars plus 1 char for terminator
	char num_input[10]; //declare char of varable num_input  9 chars plus 1 char for terminator
	unsigned int position;  //declare a non-negative int of variable position
	printf("Type not empty string (q - to quit):\n"); //asking the user to enter string or q to quit
	printf("01234567890123456789012345678901234567890123456789012345678901234567890123456789\n");  //prints to screen
	gets(buffer1); //prompt user to enter a string value
	while (strcmp(buffer1, "q") != 0) { //compare ASCII value of first charcater of buffer1 with q 
		printf("Type the character position within the string:\n");  //asking the user to enter the positon of character in string
		gets(num_input); //prompt user to enter a  string value in terms of number 
		position = atoi(num_input); //convert char to int 
		if (position >= strlen(buffer1)) { //compare length of buffer 1 with position
			position = strlen(buffer1) - 1; //assign last character of buffer1 to position  
			printf("Too big... Position reduced to max. available\n");  //prints to screen
		}
		printf("The character found at %d position is \'%c\'\n", position, buffer1[position]);  //prints to screen value of position and buffer1[position]
		printf("Type not empty string (q - to quit):\n"); //asking the user to enter string or q to quitprints to screen
		printf("01234567890123456789012345678901234567890123456789012345678901234567890123456789\n");  //prints to screen
		gets(buffer1); //prompt user to enter a string value and call gets(buffer1) function
	}
	printf("*** End of Indexing Strings Demo ***\n\n"); //prints to screen if q is entered 

}




#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fundamentals.h"

void fundamentals() {
	/* Version 1 */
	printf("***Start of Indexing Strings Demo ***\n");
	char buffer1[80];  //declare char of varable buffer1 with 79 chars plus 1 char for terminator
	char num_input[10]; //declare char of varable num_input  9 chars plus 1 char for terminator
	unsigned int position;  //declare a non-negative int of variable position
	printf("Type not empty string (q - to quit):\n"); //asking the user to enter string or q to quit
	printf("01234567890123456789012345678901234567890123456789012345678901234567890123456789\n");  //prints to screen
	gets(buffer1); //prompt user to enter a string value
	while (strcmp(buffer1, "q") != 0) { //compare ASCII value of first charcater of buffer1 with q 
		printf("Type the character position within the string:\n");  //asking the user to enter the positon of character in string
		gets(num_input); //prompt user to enter a  string value in terms of number 
		position = atoi(num_input); //convert char to int 
		if (position >= strlen(buffer1)) { //compare length of buffer 1 with position
			position = strlen(buffer1) - 1; //assign last character of buffer1 to position  
			printf("Too big... Position reduced to max. available\n");  //prints to screen
		}
		printf("The character found at %d position is \'%c\'\n", position, buffer1[position]);  //prints to screen value of position and buffer1[position]
		printf("Type not empty string (q - to quit):\n"); //asking the user to enter string or q to quitprints to screen
		printf("01234567890123456789012345678901234567890123456789012345678901234567890123456789\n");  //prints to screen
		gets(buffer1); //prompt user to enter a string value and call gets(buffer1) function
	}
	printf("*** End of Indexing Strings Demo ***\n\n"); //prints to screen if q is entered 

}


