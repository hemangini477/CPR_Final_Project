#include "fundamentals.h"
#include "manipulating.h"
#include "converting.h"
#include "tokenizing.h"

int main() 
{
	// call function fundamentals
	fundamentals();
	// call function manipulating
	manipulating();
	// call function converting
	converting();
	// call function tokenizing
	tokenizing();

	return 0;
}