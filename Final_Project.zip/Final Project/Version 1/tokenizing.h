#ifndef _TOKENIZING_H
#define _TOKENIZING_H

#include <stdio.h>
#include <string.h>
void tokenizing();

#endif
