#ifndef _MANIPULATING_H
#define _MANIPULATING_H

#include<stdio.h>
#include<string.h>

// declare function manipulating
void manipulating();

#endif
