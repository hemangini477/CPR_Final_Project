/*
Origin:
	Name: Bhavikkumar Hemantbhai Mistry,
	email: bhmistry@myseneca.ca,
	ID: 128788213,
	Date written: 01-12-2021,
	Course: CPR 101, Project: Version 1
executable filename: Tokenizing
Purpose: Breaks string into a series of tokens using the delimiter
*/
/* Version 1 */

#define _CRT_SECURE_NO_WARNINGS

#include "tokenizing.h"

// definition of function tokenizing
void tokenizing() 
{

	printf("*** Start of Tokenizing Words Demo ***\n"); 
	char words[200]; 
	char* word; 
	int w_counter; 
	printf("Type a few words seperated by space(q - to quit):\n"); 
	gets(words);

	// define loop to token words until quit
	while (strcmp(words, "q") != 0) // compare words with q
	{
		word = strtok(words, " ");// Here we have used strtok function which will breaks string words into a series of tokens using the delimiter space.
		w_counter = 1; 
		
		while (word) // This while loop is used to print all the words seperated by delimiter space
		{
			printf("Word #%d is \'%s\'\n", w_counter++, word);
			word = strtok(NULL, " "); //This function is used again to extract the next word.
		}
		printf("Type a few words seperated by space(q - to quit):\n"); 
		gets(words);
	}

	printf("*** End of Tokenizing Words Demo ***\n\n");// Print the statement when the user enter 'q'.
}